'use strict';
module.exports = {
    secret: 'lynking-secret',
    database: 'mongodb://hector:guo@ds041566.mlab.com:41566/hectorguo',
    corsWhitelist: ['http://4113studio.com','localhost']
}