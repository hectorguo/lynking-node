'use strict';
module.exports = {
    secret: 'lynking-secret',
    database: process.env.NODE_ENV === 'development' ? 'mongodb://localhost:27017/hectorguo' : 'mongodb://hector:guo@ds041566.mlab.com:41566/hectorguo',
    corsWhitelist: ['null','https://4113studio.com','http://4113studio.com','https://localhost','http://localhost','https://lynking.github.io','http://lynking.us','https://lynking.us','http://www.lynking.us','https://www.lynking.us','http://www.lynking.in','https://www.lynking.in','http://lynking.in','https://lynking.in']
}